# Copyright (C) 2023 - 2024 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""

Full heart EP-mechanics
-----------------------
This example shows you how to consume a full heart model and
set it up for a coupled electromechanical simulation.
"""

###############################################################################
# Example setup
# -------------
# before computing the fiber orientation, purkinje network we need to load
# the required modules, load a heart model and set up the simulator.
#
# Perform the required imports
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Import the required modules and set relevant paths, including that of the working
# directory, model, and ls-dyna executable.

# sphinx_gallery_start_ignore
# Note that we need to put the thumbnail here to avoid weird rendering in the html page.
# sphinx_gallery_thumbnail_path = '_static/images/thumbnails/fh_epmeca.png'
# sphinx_gallery_end_ignore

import os

from pint import Quantity

import ansys.heart.preprocessor.models as models
from ansys.heart.simulator.settings.material.ep_material import EPMaterial
from ansys.heart.simulator.settings.material.material import NeoHookean
from ansys.heart.simulator.simulator import DynaSettings, EPMechanicsSimulator

###############################################################################
# Example setup
# -------------
# Perform the required imports
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Import the required modules and set relevant paths, including that of the working
# directory and generated model

# sphinx_gallery_start_ignore
# sphinx_gallery_thumbnail_path = '/_static/images/full_heart_mesh.png'
# sphinx_gallery_end_ignore

# accept dpf license aggrement
# https://dpf.docs.pyansys.com/version/stable/getting_started/licensing.html#ref-licensing
os.environ["ANSYS_DPF_ACCEPT_LA"] = "Y"

# specify necessary paths.
# Note that we need to cast the paths to strings to facilitate serialization.
case_file = os.path.join("pyansys-heart", "downloads", "Rodero2021", "01", "01.vtk")
workdir = os.path.join(os.path.dirname(case_file), "FullHeart")

# sphinx_gallery_start_ignore
# Overwrite with env variables: for testing purposes only. May be removed by user.
try:
    from pathlib import Path

    path_to_dyna = str(Path(os.environ["PATH_TO_DYNA"]))
    workdir = os.path.join(os.path.dirname(str(Path(os.environ["PATH_TO_CASE_FILE"]))), "FullHeart")
except KeyError:
    pass
# sphinx_gallery_end_ignore

path_to_model = os.path.join(workdir, "heart_model.vtu")

###############################################################################
# Load the full heart model
# ~~~~~~~~~~~~~~~~~~~~~~~~~

# instantiate a four chamber model
model: models.FullHeart = models.FullHeart(models.ModelInfo(work_directory=workdir))
model.load_model_from_mesh(path_to_model, path_to_model.replace(".vtu", ".partinfo.json"))
model._extract_apex()
model.compute_left_ventricle_anatomy_axis()
model.compute_left_ventricle_aha17()


###############################################################################
# Instantiate the simulator object
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# instantiate the simulator and settings appropriately.

# instantaiate dyna settings of choice
lsdyna_path = r"your_dyna_exe"  # tested with DEV-111820
dyna_settings = DynaSettings(
    lsdyna_path=lsdyna_path, dynatype="intelmpi", platform="wsl", num_cpus=6
)

# sphinx_gallery_start_ignore
# Overwrite with env variables: for testing purposes only. May be removed by user.
try:
    dyna_settings.lsdyna_path = path_to_dyna
    # assume we are in WSL if .exe not in path.
    if ".exe" not in path_to_dyna:
        dyna_settings.platform = "wsl"
except:
    pass
# sphinx_gallery_end_ignore

# instantiate simulator object
simulator = EPMechanicsSimulator(
    model=model,
    dyna_settings=dyna_settings,
    simulation_directory=os.path.join(workdir, "ep-mechanics"),
)

# load default simulation settings
simulator.settings.load_defaults()

# compute fiber orientation in the ventricles and atria
simulator.compute_fibers()
simulator.compute_left_atrial_fiber()
simulator.compute_right_atrial_fiber(appendage=[39, 29, 98])

# switch atria to active
simulator.model.left_atrium.fiber = True
simulator.model.left_atrium.active = True

simulator.model.right_atrium.fiber = True
simulator.model.right_atrium.active = True

## Optionally, we can create more anatomical details.
## Sometimes, it's in favor of convergence rate of mechanical solve

# Extract elements around atrial caps and assign as a passive material
ring = simulator.model.create_atrial_stiff_ring(radius=5)
# material is stiff and value is arbitrarily chosen
ring.meca_material = NeoHookean(rho=0.001, c10=0.1, nu=0.499)
# assign default EP material as for atrial
ring.ep_material = EPMaterial.Active()

# Extract elements around atrialvenricular valves and assign as a passive material
simulator.create_stiff_ventricle_base(stiff_material=NeoHookean(rho=0.001, c10=0.1, nu=0.499))


# Estimate the stress-free-configuration
simulator.compute_stress_free_configuration()

# Compute the conduction system
simulator.compute_purkinje()
simulator.compute_conduction_system()


###############################################################################
# Start main simulation
# ~~~~~~~~~~~~~~~~~~~~~
simulator.settings.mechanics.analysis.end_time = Quantity(800, "ms")
simulator.settings.mechanics.analysis.dt_d3plot = Quantity(10, "ms")

simulator.model.dump_model(os.path.join(workdir, "heart_fib_beam.pickle"))

###############################################################################
# .. note::
#    A constant pressure is prescribed to the atria.
#    No circulation system is coupled with the atria.

# start main simulation
simulator.dyna_settings.num_cpus = 10
simulator.simulate()

###############################################################################
# Result in LS-PrePost

###############################################################################
# .. video:: ../../_static/images/doc_Christobal01_epmeca_fh.mp4
#   :width: 600
#   :loop:
#   :class: center
