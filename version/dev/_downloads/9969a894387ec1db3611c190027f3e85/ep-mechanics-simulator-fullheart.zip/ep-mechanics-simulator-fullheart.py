# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""

Run a full-heart EP mechanics simulation
----------------------------------------
This example shows how to consume a full-heart model and
set it up for a coupled electromechanical simulation.
"""
###############################################################################
# .. warning::
#    When using a standalone version of the DPF Server, you must accept the `license terms
#    <https://dpf.docs.pyansys.com/version/stable/getting_started/licensing.html>`_. To
#    accept these terms, you can set this environment variable:
#
#    .. code-block:: python
#
#        import os
#        os.environ["ANSYS_DPF_ACCEPT_LA"] = "Y"

###############################################################################
# Perform the required imports
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Import the required modules.

import os
from pathlib import Path

import numpy as np
from pint import Quantity

from ansys.health.heart.examples import get_preprocessed_fullheart
import ansys.health.heart.models as models
from ansys.health.heart.settings.material.cell_models import (
    TentusscherEndo,
    TentusscherEpi,
    TentusscherMid,
)
import ansys.health.heart.settings.material.ep_material_factory as ep_material_factory
from ansys.health.heart.settings.material.material import ISO, Mat295
from ansys.health.heart.simulator import DynaSettings, EPMechanicsSimulator

###############################################################################
# Set the required paths
# ~~~~~~~~~~~~~~~~~~~~~~
# Set the working directory and path to the model.

# Get the path to a preprocessed full-heart model.
path_to_model, path_to_partinfo, _ = get_preprocessed_fullheart(resolution="2.0mm")

# Set the working directory.
workdir = Path.home() / "pyansys-heart" / "downloads" / "Rodero2021" / "01" / "FullHeart"

###############################################################################
# Load the full-heart model
# ~~~~~~~~~~~~~~~~~~~~~~~~~

# Load the full-heart model.
model = models.HeartModel.load_model(path_to_model, path_to_partinfo, working_directory=workdir)

###############################################################################
# Instantiate the simulator
# ~~~~~~~~~~~~~~~~~~~~~~~~~
# Instantiate the simulator and define settings.

###############################################################################
# .. note::
#    The ``DynaSettings`` object supports several LS-DYNA versions and platforms,
#    including ``smp``, ``intempi``, ``msmpi``, ``windows``, ``linux``, and ``wsl``.
#    Choose the one that works for your setup.

lsdyna_path = r"your_dyna_exe"
dyna_settings = DynaSettings(
    lsdyna_path=lsdyna_path, dynatype="intelmpi", platform="windows", num_cpus=4
)

# Instantiate the simulator.
simulator = EPMechanicsSimulator(
    model=model,
    dyna_settings=dyna_settings,
    simulation_directory=os.path.join(workdir, "ep-mechanics"),
)

# Load default simulation settings.
simulator.settings.load_defaults()

# Use the ReactionEikonal solver for the electrophysiology simulation.
simulator.settings.electrophysiology.analysis.solvertype = "ReactionEikonal"

###############################################################################
# Compute the fiber orientation
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Compute the fiber orientation on the entire model.

# Import the appendage landmarks.
from ansys.health.heart.pre.database_utils import right_atrium_appendage_landmarks

# Get the right atrium appendage landmark of the first case of Rodero2021.
right_atrium_appendage_coordinates = right_atrium_appendage_landmarks.get("Rodero2021").get(1)

# Compute fiber orientation in the ventricles and atria.
simulator.compute_fibers()
simulator.compute_left_atrial_fiber()
simulator.compute_right_atrial_fiber(appendage=right_atrium_appendage_coordinates)

# Switch the atria to active.
simulator.model.left_atrium.fiber = True
simulator.model.left_atrium.active = True

simulator.model.right_atrium.fiber = True
simulator.model.right_atrium.active = True

###############################################################################
# Set up the simulation for the mechanical simulations
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Extract elements around atrial caps and assign as a passive material.
ring = simulator.model.create_atrial_stiff_ring(radius=5)

# Assign a material that is stiffer than the surrounding material.
stiff_iso = Mat295(rho=0.001, iso=ISO(itype=-1, beta=2, kappa=10, mu1=0.1, alpha1=2))
ring.meca_material = stiff_iso

# Assign the default EP material
ring.ep_material = ep_material_factory.get_default_myocardium_material(
    simulator.settings.electrophysiology.analysis.solvertype
)

# plot the mesh
simulator.model.plot_mesh()

# Compute UHCs (Universal Heart Coordinates).
simulator.compute_uhc()

# Extract nodes in the endocardium, mid-myocardium, and epicardium based by transmural coordinate.
# Values from experimental data. See:
# https://www.frontiersin.org/articles/10.3389/fphys.2019.00580/full
values = simulator.model.mesh.point_data["transmural"]

th_endo = simulator.settings.electrophysiology.layers["percent_endo"].m
percent_mid = simulator.settings.electrophysiology.layers["percent_mid"].m
th_mid = th_endo + percent_mid

endo_nodes = (np.nonzero(np.logical_and(values >= 0, values < th_endo)))[0]
mid_nodes = (np.nonzero(np.logical_and(values >= th_endo, values < th_mid)))[0]
epi_nodes = (np.nonzero(np.logical_and(values >= th_mid, values <= 1)))[0]

# Define cell model for each layer and assign to the corresponding nodesets.
simulator.model._nodeset_cellmodel = (
    [endo_nodes, mid_nodes, epi_nodes],
    [TentusscherEndo(), TentusscherMid(), TentusscherEpi()],
)

# Extract elements close to the valves and assign these a passive material.
simulator.model.create_stiff_ventricle_base(stiff_material=stiff_iso)

# Compute the stress-free configuration.
simulator.compute_stress_free_configuration(overwrite=True)

###############################################################################
# .. note::
#    Computing the stress-free configuration is required since the geometry is imaged
#    at end-of-diastole. The ``compute_stress_free_configuration()`` method runs a
#    sequence of static simulations to estimate the stress-free state of the model and
#    the initial stresses present. This step is computationally expensive and can take
#    relatively long. You can consider reusing earlier runs by setting the ``overwrite``
#    flag to ``False``. This reuses the results of the previous run.

###############################################################################
# Compute a conduction system
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Compute the conduction system.
simulator.compute_purkinje()

# Use landmarks to compute the rest of the conduction system.
simulator.compute_conduction_system()

# Plot the computed conduction system.
simulator.model.plot_purkinje()

###############################################################################
# Start the main simulation
# ~~~~~~~~~~~~~~~~~~~~~~~~~
# Set the simulation end time and frequency of output files.
simulator.settings.mechanics.analysis.end_time = Quantity(800, "ms")
simulator.settings.mechanics.analysis.dt_d3plot = Quantity(10, "ms")

# Save the model to a file.
simulator.model.save_model(os.path.join(workdir, "heart_fib_beam.vtu"))

###############################################################################
# .. note::
#    A constant pressure is prescribed to the atria.
#    No circulation system is coupled with the atria.

# Start main simulation. The ``auto_post`` option is set to ``False`` to avoid
# automatic postprocessing.
simulator.simulate(auto_post=False)

###############################################################################
# .. note::
#    The ``ReactionEikonal`` solver is suitable for coarse meshes and is
#    included here for demonstration purposes. However, it currently supports
#    only a single cardiac cycle. To simulate multiple cardiac cycles, use the
#    ``Monodomain`` solver, which requires a fine mesh and small time step size.

###############################################################################
# Visualize and animate results LS-PrePost
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

###############################################################################
# .. only:: html
#
#     .. video:: ../../_static/images/rodero_epmechanics_fullheart.mp4
#       :width: 600
#       :loop:
#       :class: center
